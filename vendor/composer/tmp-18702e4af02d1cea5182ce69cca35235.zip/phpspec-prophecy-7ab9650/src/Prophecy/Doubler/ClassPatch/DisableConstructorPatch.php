<?php

/*
 * This file is part of the Prophecy.
 * (c) Konstantin Kudryashov <ever.zet@gmail.com>
 *     Marcello Duarte <marcello.duarte@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Prophecy\Doubler\ClassPatch;

use Prophecy\Doubler\Generator\Node\ArgumentTypeNode;
use Prophecy\Doubler\Generator\Node\ClassNode;
use Prophecy\Doubler\Generator\Node\MethodNode;
use Prophecy\Doubler\Generator\Node\Type\BuiltinType;
use Prophecy\Doubler\Generator\Node\Type\UnionType;

/**
 * Disable constructor.
 * Makes all constructor arguments optional.
 *
 * @author Konstantin Kudryashov <ever.zet@gmail.com>
 */
class DisableConstructorPatch implements ClassPatchInterface
{
    /**
     * Checks if class has `__construct` method.
     *
     * @param ClassNode $node
     *
     * @return bool
     */
    public function supports(ClassNode $node)
    {
        return true;
    }

    /**
     * Makes all class constructor arguments optional.
     *
     * @param ClassNode $node
     */
    public function apply(ClassNode $node)
    {
        if (!$node->isExtendable('__construct')) {
            return;
        }

        if (!$node->hasMethod('__construct')) {
            $node->addMethod(new MethodNode('__construct', ''));

            return;
        }

        $constructor = $node->getMethod('__construct');
        \assert($constructor !== null);
        foreach ($constructor->getArguments() as $argument) {
            $argument->setDefault(null);

            $type = $argument->getTypeNode()->getType();
            if (
                $type instanceof BuiltinType
                && ($type->getType() === 'null' || $type->getType() === 'mixed')
            ) {
                continue;
            }

            if ($type instanceof UnionType && $type->has(new BuiltinType('null'))) {
                continue;
            }

            if (null === $type) {
                continue;
            }

            if ($type instanceof UnionType) {
                $argument->setTypeNode(new ArgumentTypeNode(new UnionType(
                    [new BuiltinType('null'), ...$type->getTypes()]
                )));
                continue;
            }

            $argument->setTypeNode(new ArgumentTypeNode(new UnionType(
                [new BuiltinType('null'), $type]
            )));
        }

        $constructor->setCode(<<<PHP
if (0 < func_num_args()) {
    call_user_func_array(array(parent::class, '__construct'), func_get_args());
}
PHP
        );
    }

    /**
     * Returns patch priority, which determines when patch will be applied.
     *
     * @return int Priority number (higher - earlier)
     */
    public function getPriority()
    {
        return 100;
    }
}
