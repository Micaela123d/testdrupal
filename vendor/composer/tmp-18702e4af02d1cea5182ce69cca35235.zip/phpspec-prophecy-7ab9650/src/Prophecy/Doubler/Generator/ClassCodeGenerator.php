<?php

/*
 * This file is part of the Prophecy.
 * (c) Konstantin Kudryashov <ever.zet@gmail.com>
 *     Marcello Duarte <marcello.duarte@gmail.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Prophecy\Doubler\Generator;

use Prophecy\Doubler\Generator\Node\ReturnTypeNode;
use Prophecy\Doubler\Generator\Node\Type\IntersectionType;
use Prophecy\Doubler\Generator\Node\Type\ObjectType;
use Prophecy\Doubler\Generator\Node\Type\SimpleType;
use Prophecy\Doubler\Generator\Node\Type\TypeInterface;
use Prophecy\Doubler\Generator\Node\Type\UnionType;
use Prophecy\Doubler\Generator\Node\TypeNodeAbstract;
use Prophecy\Exception\Doubler\ClassCreatorException;

/**
 * Class code creator.
 * Generates PHP code for specific class node tree.
 *
 * @author Konstantin Kudryashov <ever.zet@gmail.com>
 */
class ClassCodeGenerator
{
    // Used to accept an optional first argument with the deprecated Prophecy\Doubler\Generator\TypeHintReference so careful when adding a new argument in a minor version.
    public function __construct() {}

    /**
     * Generates PHP code for class node.
     *
     * @param string         $classname
     * @param Node\ClassNode $class
     *
     * @return string
     */
    public function generate($classname, Node\ClassNode $class)
    {
        $parts     = explode('\\', $classname);
        $classname = array_pop($parts);
        $namespace = implode('\\', $parts);

        $code = sprintf("%sclass %s extends \%s implements %s {\n",
            $class->isReadOnly() ? 'readonly ' : '',
            $classname,
            $class->getParentClass(),
            implode(', ',
                array_map(function ($interface) {return '\\'.$interface;}, $class->getInterfaces())
            )
        );

        foreach ($class->getProperties() as $name => $visibility) {
            $code .= sprintf("%s \$%s;\n", $visibility, $name);
        }
        $code .= "\n";

        foreach ($class->getMethods() as $method) {
            $code .= $this->generateMethod($method)."\n";
        }
        $code .= "\n}";

        return sprintf("namespace %s {\n%s\n}", $namespace, $code);
    }

    private function generateMethod(Node\MethodNode $method): string
    {
        $php = sprintf("%s %s function %s%s(%s)%s {\n",
            $method->getVisibility(),
            $method->isStatic() ? 'static' : '',
            $method->returnsReference() ? '&' : '',
            $method->getName(),
            implode(', ', $this->generateArguments($method->getArguments())),
            ($ret = $this->generateTypes($method->getReturnTypeNode())) ? ': '.$ret : ''
        );
        $php .= $method->getCode()."\n";

        return $php.'}';
    }

    private function generateTypes(TypeNodeAbstract $typeNode): string
    {
        if ($typeNode->getType() === null) {
            return '';
        }

        return (string) $typeNode->getType();
    }

    /**
     * @param list<Node\ArgumentNode> $arguments
     *
     * @return list<string>
     */
    private function generateArguments(array $arguments): array
    {
        return array_map(function (Node\ArgumentNode $argument) {

            $php = $this->generateTypes($argument->getTypeNode());

            $php .= ' '.($argument->isPassedByReference() ? '&' : '');

            $php .= $argument->isVariadic() ? '...' : '';

            $php .= '$'.$argument->getName();

            if ($argument->isOptional() && !$argument->isVariadic()) {
                $default = var_export($argument->getDefault(), true);

                // This is necessary for PHP 8.1, as enum cases are exported without a leading slash in this version
                if ($argument->getDefault() instanceof \UnitEnum && 0 !== strpos($default, '\\')) {
                    $default = '\\'.$default;
                }

                $php .= ' = '.$default;
            }

            return $php;
        }, $arguments);
    }
}
